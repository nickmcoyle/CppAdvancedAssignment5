#pragma once

#include "IBitmapIterator.h"
#include <memory>
#include <string>
#include <iostream>

namespace BitmapGraphics
{      
	class IBitmapEncoder;
	using HBitmapEncoder = std::shared_ptr<IBitmapEncoder>;

    class IBitmapEncoder
    {
    public:
		IBitmapEncoder() = default;
		virtual ~IBitmapEncoder() = default;
        
		IBitmapEncoder(const IBitmapEncoder&) = delete;
		IBitmapEncoder& operator =(IBitmapEncoder const&) = delete;
		IBitmapEncoder(IBitmapEncoder&&) = delete;
		IBitmapEncoder& operator=(IBitmapEncoder&&) = delete;
		
    	virtual HBitmapEncoder clone(HBitmapIterator bitmapIterator) = 0;
        
        virtual void encodeToStream(std::ostream& os) = 0;
        
        virtual std::string getMimeType() const = 0;
    };
}