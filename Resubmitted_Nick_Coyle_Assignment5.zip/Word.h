#pragma once

#include "SizedWord.h"

namespace Binary
{
    using Word = SizedWord<std::uint16_t>;
}

